# Word 正式交付规则

## 目的

销售月报审核不是只给 Codex 或技术人员看。部长、主管、业务人员、老板助理更常用 Word 文档流转、保存和打印。

因此正式初审、深度审核、C/D 打回整改、复审结果，默认不能只生成 Markdown。Markdown 是可追溯底稿，Word 是业务流转正式版。

默认交付以“完整 14 模块主报告 Word 正式版 + Markdown 底稿”为主。A 类额外单独生成老板一页纸正式版；B/C/D 的补充清单、主管整改版、重做通知默认放在主报告前部的“部长重点看”章节，不另拆多个文件，除非用户明确要求。

## 原月报查看提醒的保留规则

原月报中的“填写说明”“AI审核点”“格式合规提醒”“模板说明”等提示文字，是给业务人员和部长查看时使用的辅助信息。生成审核 Word 时不要求删除或清理这些内容；审核报告如需说明，可单独写为“查看提醒识别：已保留，不计入审核错误”。

除非提示文字本身包含明确的错误月份、未替换数字或实际数据冲突，否则不得把它们列为硬伤、扣分项、最高分限制或整改要求。

## 默认双交付

以下场景默认同时生成两份：

1. Markdown 底稿：用于版本追踪、继续复审、复制到飞书或二次编辑。
2. Word 文档：用于部长、主管、业务人员保存、转发、打印和正式流转。

必须双交付的场景：

- 部长或管理者只贴飞书链接发起正式初审；
- 正式初审；
- 完整 14 模块报告；
- 深度经营诊断；
- A 类老板一页纸正式版；
- C 类 / D 类主报告中的主管整改或重做重点区；
- 复审结论需要留档；
- 用户说“给主管、给部门、给老板、留档、正式版、业务人员看”。

## 文件命名

Markdown：

```text
outputs/feishu_monthly_audit/部门或小组_YYYY-MM_销售月报AI初审报告.md
```

Word：

```text
outputs/feishu_monthly_audit/部门或小组_YYYY-MM_销售月报AI初审报告.docx
```

文件名必须使用中文业务名，部门或小组放在月份前面，例如：

```text
抖音商城组_2026-06_销售月报AI初审报告.docx
抖音商城组_2026-06_销售月报AI初审报告.md
天猫组_2026-06_老板一页纸正式版.docx
```

不得把英文 slug 当作正式交付文件名，例如 `2026-06_douyin_mall_sales_monthly_audit_report.docx`、`douyin_mall_sales_monthly_audit_report.md`、`tmall_boss_page.docx`。这类名称只能作为临时中间文件；发给部长、主管或老板前必须重命名为中文业务名。

如果是复审：

```text
outputs/feishu_monthly_audit/部门或小组_YYYY-MM_销售月报AI复审结果.md
outputs/feishu_monthly_audit/部门或小组_YYYY-MM_销售月报AI复审结果.docx
```

## 聊天区展示顺序

聊天区给报告路径时，Word 放在前面，Markdown 放在后面：

```text
完整报告已生成：
- Word 正式版：...
- Markdown 底稿：...
```

不能只展示 Markdown 路径，除非 Word 生成失败。

A 类和复审通过后的老板一页纸必须展示单独老板一页纸路径：

```text
老板一页纸正式版：...
```

复审通过后的老板一页纸内容不能只是“复审通过 + 评分 + 轻量修正”，也不能把复审整改过程、提交前处理建议或主管整改指令原样搬给老板。必须按 `shuchu-muban.md` 的增强规则，带出关键经营数据、老板关注点/经营风险、渠道/品项风险、费用效率抓手、下月验收动作、老板追问和期待回答标准；缺少的数据要明确标注，不得自行猜测。

B/C/D 必须说明主报告重点区位置，例如：

```text
部长重点看：主报告开头的“主管整改版 / 部长重点看”章节。
```

## Word 生成失败时

如果当前环境缺少文档处理能力，或 Word 生成失败：

1. 不阻断审核结论；
2. 交付 Markdown 底稿；
3. 在聊天区明确说明“Word 正式版生成失败/当前环境缺少文档处理能力”；
4. 说明下一步：可在有 Word 生成能力的 Codex 环境中用 Markdown 底稿转换，或安装/启用文档处理能力后重试。

## Word 表格转换和验收

正式 Word 不能只是把 Markdown 文本逐段写入 `.docx`。如果 Markdown 底稿里有管道符表格，例如：

```text
| 问题 | 类型 | 主管整改要求 |
|---|---|---|
```

生成 Word 时必须转换为真实 Word 表格。生成后必须做结构检查：

1. 如果 Markdown 底稿包含 N 个表格，DOCX 中必须至少有 N 个真实表格。
2. DOCX 段落中不得残留 `|---|`、`| 问题 | 类型 |`、`| 维度 | 满分 |` 这类 Markdown 表格行。
3. 检查失败时，不能把该 DOCX 作为 Word 正式版交付；必须重新转换或明确说明 Word 生成失败，只交付 Markdown 底稿。
4. 当前环境没有更高质量转换器时，优先使用 `scripts/Convert-MarkdownMonthlyAuditToDocx.ps1`：

```powershell
powershell -ExecutionPolicy Bypass -File scripts/Convert-MarkdownMonthlyAuditToDocx.ps1 `
  -MarkdownPath "outputs/feishu_monthly_audit/抖音商城组_2026-06_销售月报AI初审报告.md" `
  -OutputPath "outputs/feishu_monthly_audit/抖音商城组_2026-06_销售月报AI初审报告.docx" `
  -StrictName
```

## 不允许

- 不允许正式初审只生成 `.md`，然后让业务人员自己找软件打开。
- 不允许把“Markdown 报告已生成”当作部长端完整交付。
- 不允许 Word 只包含简化摘要而 Markdown 才有完整 14 模块；Word 必须包含完整报告主体。
- 不允许 B/C/D 主报告缺少“部长重点看”章节。
- 不允许在聊天区只贴 Markdown 路径，不提示 Word 是否生成。
